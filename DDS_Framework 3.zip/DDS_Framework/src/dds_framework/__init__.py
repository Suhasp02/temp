"""DDS PySpark ingestion framework package."""

from .ingestion_job import main

__all__ = ["main"]
