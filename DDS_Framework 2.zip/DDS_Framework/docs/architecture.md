# DDS PySpark Ingestion Framework

## Vision
Provide analysts with a reusable PySpark framework that ingests data from curated Hive views into target Hive external tables with resilient schema evolution, automatic partition filtering, and configurable resource management.

## Core Requirements Mapping
- **Inputs**: view name, target table name, load method (append | overwrite), job name, user name. Optional resource overrides.
- **Behavior**:
  - Enforce `src_system`, `site_id`, and `biz_dt` filters when reading the view. If `biz_dt` filter is missing, derive it using the latest available biz_dt in the view.
  - Create target external table if it does not exist (respecting Hive metastore in Cloudera Data Platform).
  - Reconcile schema when table exists: add missing columns to target table, populate missing columns from view with `NULL` in write DataFrame.
  - Support append and overwrite load modes.
  - (Audit removed) Only operational logs are kept; no audit table.
- **Operational**:
  - Spark resource knobs (executors, memory) configurable via CLI flags and INI-driven submit conf.
  - Delivered with a shell wrapper that builds the `spark-submit` command.

## Package Layout
```
src/
  dds_framework/
    __init__.py
    logging_utils.py   # Structured logging setup for Python
    filters.py         # Build mandatory filters and resolve latest biz_dt
    schema_manager.py  # Compare schemas; generate ALTER statements & DataFrame adjustments
    hive_utils.py      # Thin layer around Spark catalog/HMS interactions
    ingestion_job.py   # Orchestrates the end-to-end load
bin/
  run_ingestion.sh     # spark-submit entrypoint wrapper
conf/
  jobs.config          # INI with [common] and [jobs.<name>] sections
docs/
  architecture.md
  README.md (generated later)
```

## Data Flow Contract
1. **Parameter capture**: Analysts launch `bin/run_ingestion.sh JOB_NAME`. The wrapper reads the `common` + job block from `conf/jobs.config` (INI), merges dotted keys for `spark_conf.*` and `submit_conf.*`, and maps resource settings to `spark-submit --conf`. It prints a single final command for copy/paste; it does not execute locally.
2. **Spark session bootstrap**: Within `ingestion_job.py`, build a SparkSession configured for Hive support and propagate resource settings.
3. **View read & filtering**:
   - Use `filters.build_filters()` with provided `src_system`, `site_id`, `biz_dt` (optional) to create a Spark SQL predicate string.
   - If `biz_dt` not supplied, execute `SELECT MAX(biz_dt)` against the view (post filtering by system/site if supplied) to determine the partition date.
   - Load the DataFrame via `spark.table(view_name).where(predicate)`.
4. **Schema orchestration**:
   - `hive_utils.table_exists()` to branch between create vs update.
   - `schema_manager.align_table_schema()` introspects Hive metastore to:
     - Identify columns in target missing from DataFrame ⇒ add `lit(None)` columns to DataFrame.
     - Identify columns in DataFrame not in target ⇒ emit `ALTER TABLE ADD COLUMNS` commands before the write.
   - Ensure all columns are lower-cased and ordered.
5. **Write execution**:
  - Choose `mode` = `append`/`overwrite`.
  - Target managed as external by specifying storage location; pass `--target-location` for first create.

## Configuration Strategy
- Single INI file at `conf/jobs.config` containing:
  - `[common]` with shared defaults (log level, resource knobs, Spark/submit conf, spark_options)
  - `[jobs.<name>]` for each job with required entries (`view_name`, `target_table`, `load_method`, `user_name`) and optional filters/resources.
- No Python `config.py` layer; the shell wrapper translates INI into `spark-submit` args and `--conf` entries.

## Job Config File
- Stored in a single INI document at `conf/jobs.config` with sections `[common]` and `[jobs.<name>]`.
- `common` holds defaults shared by all jobs (log level, resource knobs, Spark conf via `spark_conf.*`, submit conf via `submit_conf.*`, and list-style `spark_options`).
- `jobs.<name>` maps each job name to its specific parameters. Required keys per job: `view_name`, `target_table`, `load_method`, `user_name`. Optional entries mirror CLI flags (`src_system`, `site_id`, `biz_dt`, `target_location`). Queue and audit are not supported.
- Analysts run `bin/run_ingestion.sh <job_name>`; the wrapper builds and prints the final `spark-submit` command.

## Error Handling & Observability
- Structured logging at INFO/ERROR with job context (job name, user, table).
- `bin/run_ingestion.sh` creates `logs/` if needed and writes two log files per run: one capturing wrapper activity (`<job>_shell_<timestamp>.log`) and one for Spark execution (`<job>_spark_<timestamp>.log`). The latter is also passed to the Python logger so analysts have a consolidated Spark view on disk.
- Wrap key steps in try/except to raise descriptive errors.
- Return non-zero exit for failed loads so orchestration layers can retry/alert.

## Extensibility Considerations
- Future connectors (e.g., Kafka, S3) can reuse schema manager and audit layers.
- Partitioning strategy (e.g., dynamic partitions by `biz_dt`) configured via defaults file.
- Hooks (pre/post load) can be added to `ingestion_job.py` as optional callables for custom business logic.

## Logging 
- Need detailed logging and error handling.