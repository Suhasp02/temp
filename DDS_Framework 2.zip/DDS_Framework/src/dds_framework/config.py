"""Deprecated: config module removed. Retained temporarily for back-compat import safety."""

# This module is intentionally empty. The framework no longer uses a Python config layer.
