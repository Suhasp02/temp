"""Deprecated: table helpers are now handled via SQL in ingestion_job.py."""
