"""Deprecated: schema reconciliation is now handled by SQL in ingestion_job.py."""
