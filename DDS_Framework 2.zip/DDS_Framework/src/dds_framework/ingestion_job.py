"""Main entrypoint for DDS ingestion."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

from pyspark.sql import SparkSession

if __package__ is None or __package__ == "":  # pragma: no cover - executed in script mode
    CURRENT_DIR = Path(__file__).resolve().parent
    PACKAGE_ROOT = CURRENT_DIR.parent
    if str(PACKAGE_ROOT) not in sys.path:
        sys.path.insert(0, str(PACKAGE_ROOT))
    from dds_framework import logging_utils
else:  # pragma: no cover
    from . import logging_utils


def parse_spark_conf(values: list[str]) -> Dict[str, str]:
    overrides: Dict[str, str] = {}
    for entry in values:
        if "=" not in entry:
            raise ValueError(f"Invalid --spark-conf entry '{entry}'. Expected key=value format.")
        key, value = entry.split("=", 1)
        overrides[key.strip()] = value.strip()
    return overrides


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DDS PySpark ingestion framework")
    parser.add_argument("--view-name", required=True, help="Fully qualified Hive view to read from")
    parser.add_argument("--target-table", required=True, help="Target Hive table to load")
    parser.add_argument(
        "--load-method",
        required=True,
        choices=["append", "overwrite"],
        help="Spark write mode",
    )
    parser.add_argument("--job-name", required=True, help="Logical job identifier")
    parser.add_argument("--user-name", required=True, help="Submitting analyst user ID")

    parser.add_argument("--src-system", help="Source system filter value")
    parser.add_argument("--site-id", help="Site identifier filter value")
    parser.add_argument("--biz-dt", help="Business date filter value")

    # No external config file; INI is handled by the shell wrapper
    parser.add_argument("--target-location", help="External table location path (required when creating table)")

    parser.add_argument("--log-level", default="INFO", help="Python logging level")
    parser.add_argument("--log-file", help="Path to log file for Python logger")

    parser.add_argument("--spark-executor-instances", type=int)
    parser.add_argument("--spark-executor-memory", help="Executor memory, e.g. 4g")
    parser.add_argument("--spark-driver-memory", help="Driver memory, e.g. 2g")
    parser.add_argument("--spark-executor-cores", type=int)
    parser.add_argument(
        "--spark-conf",
        action="append",
        default=[],
        help="Additional Spark conf in key=value format. Can be repeated.",
    )

    return parser.parse_args(argv)


def build_spark_session(job_name: str, extra_conf: Dict[str, str]) -> SparkSession:
    builder = SparkSession.builder.appName(f"dds_ingestion_{job_name}").enableHiveSupport()
    for key, value in extra_conf.items():
        builder = builder.config(key, value)
    return builder.getOrCreate()


def _sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _quote_ident(name: str) -> str:
    return f"`{name}`"


def _exec_sql(spark: SparkSession, logger: Any, sql: str):
    logger.info(f"SQL> {sql}")
    return spark.sql(sql)


def _describe_columns(spark: SparkSession, logger: Any, name: str) -> List[Tuple[str, str]]:
    """Return [(col_name_lower, data_type)] for a table or view using DESCRIBE."""
    rows = _exec_sql(spark, logger, f"DESCRIBE {name}").collect()
    cols: List[Tuple[str, str]] = []
    for r in rows:
        col = (r[0] or "").strip()
        dtype = (r[1] or "").strip()
        if not col or col.startswith("#"):
            # Skip headers/footers
            continue
        # Spark inserts a blank line then partition info; stop when reaching partition marker
        if col.lower() in ("partitioning", "# partitioning"):
            break
        cols.append((col.lower(), dtype))
    return cols


def _table_exists(spark: SparkSession, name: str) -> bool:
    return spark.catalog.tableExists(name)


def _resolve_biz_dt(
    spark: SparkSession, logger: Any, view_name: str, src_system: Optional[str], site_id: Optional[str], provided: Optional[str]
) -> Optional[str]:
    if provided:
        return provided
    predicates: List[str] = ["1=1"]
    if src_system:
        predicates.append(f"src_system = {_sql_literal(src_system)}")
    if site_id:
        predicates.append(f"site_id = {_sql_literal(site_id)}")
    where = " AND ".join(predicates)
    row = _exec_sql(
        spark,
        logger,
        f"SELECT CAST(MAX(biz_dt) AS STRING) AS biz_dt FROM {view_name} WHERE {where}",
    ).collect()[0]
    return row["biz_dt"]


def _choose_partitions(source_cols: List[Tuple[str, str]]) -> List[str]:
    names = {c for c, _ in source_cols}
    parts: List[str] = []
    for c in ("site_id", "biz_dt"):
        if c in names:
            parts.append(c)
    return parts


def _add_missing_columns(spark: SparkSession, logger: Any, table_name: str, cols_to_add: List[Tuple[str, str]]) -> None:
    if not cols_to_add:
        return
    defs = ", ".join(f"{_quote_ident(c)} {t}" for c, t in cols_to_add)
    _exec_sql(spark, logger, f"ALTER TABLE {table_name} ADD COLUMNS ({defs})")


def _set_dynamic_partitioning(spark: SparkSession, logger: Any) -> None:
    _exec_sql(spark, logger, "SET hive.exec.dynamic.partition=true")
    _exec_sql(spark, logger, "SET hive.exec.dynamic.partition.mode=nonstrict")


def _load_into_existing_table(
    spark: SparkSession,
    args: argparse.Namespace,
    logger: Any,
    source_cols: List[Tuple[str, str]],
    resolved_biz_dt: str,
) -> None:
    target_cols = _describe_columns(spark, logger, args.target_table)
    src_map = {c: t for c, t in source_cols}
    tgt_map = {c: t for c, t in target_cols}
    # Add columns that exist in source but not in target
    add_cols = [(c, src_map[c]) for c in src_map.keys() if c not in tgt_map]
    if add_cols:
        _add_missing_columns(spark, logger, args.target_table, add_cols)
        logger.info("Added new columns to target table", extra={"columns": [c for c, _ in add_cols]})
        target_cols = _describe_columns(spark, logger, args.target_table)
        tgt_map = {c: t for c, t in target_cols}

    # Determine partition columns actually used by the table
    table_parts = [p for p in ("site_id", "biz_dt") if p in {c for c, _ in target_cols}]
    non_part_cols = [c for c, _ in target_cols if c not in table_parts]

    # Build WHERE predicates
    preds: List[str] = ["1=1"]
    if args.src_system:
        preds.append(f"v.src_system = {_sql_literal(args.src_system)}")
    if args.site_id:
        preds.append(f"v.site_id = {_sql_literal(args.site_id)}")
    preds.append(f"v.biz_dt = {_sql_literal(resolved_biz_dt)}")
    where = " AND ".join(preds)

    # Build projection for append (full column order match)
    def build_full_projection() -> str:
        exprs: List[str] = []
        for col, dtype in target_cols:
            if col in src_map:
                exprs.append(f"v.{_quote_ident(col)} AS {_quote_ident(col)}")
            else:
                exprs.append(f"CAST(NULL AS {tgt_map[col]}) AS {_quote_ident(col)}")
        return ", ".join(exprs)

    # INSERT strategy
    if args.load_method == "append":
        select_list = build_full_projection()
        insert_sql = (
            f"INSERT INTO {args.target_table} SELECT {select_list} FROM {args.view_name} v WHERE {where}"
        )
        _set_dynamic_partitioning(spark, logger)
        _exec_sql(spark, logger, insert_sql)
        logger.info("Append completed via SQL INSERT INTO")
    else:  # overwrite
        _set_dynamic_partitioning(spark, logger)
        # If biz_dt is a partition, do partition-scoped overwrite
        if "biz_dt" in table_parts:
            # Determine dynamic vs static partitions
            static_parts: List[str] = [f"biz_dt={_sql_literal(resolved_biz_dt)}"]
            dynamic_parts: List[str] = [p for p in table_parts if p != "biz_dt"]

            # Build select for non-part cols then dynamic partition cols (in order)
            exprs: List[str] = []
            for col in non_part_cols:
                if col in src_map:
                    exprs.append(f"v.{_quote_ident(col)} AS {_quote_ident(col)}")
                else:
                    exprs.append(f"CAST(NULL AS {tgt_map[col]}) AS {_quote_ident(col)}")
            for p in dynamic_parts:
                exprs.append(f"v.{_quote_ident(p)} AS {_quote_ident(p)}")
            select_list = ", ".join(exprs)

            part_clause = ", ".join(static_parts)
            insert_sql = (
                f"INSERT OVERWRITE TABLE {args.target_table} PARTITION ({part_clause}) "
                f"SELECT {select_list} FROM {args.view_name} v WHERE {where}"
            )
            _exec_sql(spark, logger, insert_sql)
            logger.info(
                "Overwrite completed via SQL INSERT OVERWRITE PARTITION", extra={"biz_dt": resolved_biz_dt}
            )
        else:
            # Fallback: full table overwrite (rare)
            select_list = build_full_projection()
            insert_sql = (
                f"INSERT OVERWRITE TABLE {args.target_table} SELECT {select_list} FROM {args.view_name} v WHERE {where}"
            )
            _exec_sql(spark, logger, insert_sql)
            logger.info("Overwrite completed via full-table SQL INSERT OVERWRITE")


def run(argv: list[str]) -> int:
    args = parse_args(argv)

    logger = logging_utils.setup_logging(
        level=args.log_level,
        job_name=args.job_name,
        user_name=args.user_name,
        target_table=args.target_table,
        log_file=args.log_file,
    )
    # Build Spark conf overrides from CLI only
    spark_conf_overrides = parse_spark_conf(args.spark_conf)
    if args.spark_executor_instances is not None:
        spark_conf_overrides["spark.executor.instances"] = str(args.spark_executor_instances)
    if args.spark_executor_memory:
        spark_conf_overrides["spark.executor.memory"] = args.spark_executor_memory
    if args.spark_driver_memory:
        spark_conf_overrides["spark.driver.memory"] = args.spark_driver_memory
    if args.spark_executor_cores is not None:
        spark_conf_overrides["spark.executor.cores"] = str(args.spark_executor_cores)

    spark = build_spark_session(args.job_name, spark_conf_overrides)

    try:
        # Resolve partitions and columns
        source_cols = _describe_columns(spark, logger, args.view_name)
        partitions = _choose_partitions(source_cols)
        resolved_biz_dt = _resolve_biz_dt(
            spark, logger, args.view_name, args.src_system, args.site_id, args.biz_dt
        )
        if resolved_biz_dt is None:
            raise ValueError("Unable to resolve biz_dt from view; no rows found")

        if not _table_exists(spark, args.target_table):
            # Build CTAS SQL with optional filters and MAX(biz_dt). If target_location is provided, use LOCATION and mark EXTERNAL; otherwise let Hive/Spark infer managed table location.
            preds: List[str] = ["1=1"]
            if args.src_system:
                preds.append(f"v.src_system = {_sql_literal(args.src_system)}")
            if args.site_id:
                preds.append(f"v.site_id = {_sql_literal(args.site_id)}")
            preds.append(f"v.biz_dt = {_sql_literal(resolved_biz_dt)}")
            where = " AND ".join(preds)

            part_clause = f"PARTITIONED BY ({', '.join(partitions)})" if partitions else ""
            try:
                if args.target_location:
                    sql = (
                        f"CREATE TABLE {args.target_table} USING PARQUET {part_clause} "
                        f"LOCATION {_sql_literal(args.target_location)} AS "
                        f"SELECT v.* FROM {args.view_name} v WHERE {where}"
                    )
                    _exec_sql(spark, logger, sql)
                    # Mark as EXTERNAL when explicit LOCATION is used (common CDP convention)
                    _exec_sql(
                        spark,
                        logger,
                        f"ALTER TABLE {args.target_table} SET TBLPROPERTIES('EXTERNAL'='TRUE')",
                    )
                    logger.info("Created and loaded target table via CTAS", extra={"location": args.target_location})
                else:
                    sql = (
                        f"CREATE TABLE {args.target_table} USING PARQUET {part_clause} AS "
                        f"SELECT v.* FROM {args.view_name} v WHERE {where}"
                    )
                    _exec_sql(spark, logger, sql)
                    logger.info("Created and loaded managed table via CTAS (no LOCATION provided)")
            except Exception:
                # If another concurrent job created it, switch to existing-table path
                if _table_exists(spark, args.target_table):
                    _load_into_existing_table(spark, args, logger, source_cols, resolved_biz_dt)
                else:
                    raise
        else:
            # Existing table: schema reconcile + insert (append/overwrite)
            _load_into_existing_table(spark, args, logger, source_cols, resolved_biz_dt)

        logger.info("Ingestion completed successfully")
        return 0
    except Exception as exc:  # pylint: disable=broad-except
        logger.exception("Ingestion failed")
        return 1
    finally:
        spark.stop()


def main() -> None:
    sys.exit(run(sys.argv[1:]))
