# DDS Framework – PySpark Ingestion

This repo provides a single user-facing entry point to run ingestion jobs with Spark while keeping two separate scripts (launcher vs. Spark job) as requested.

- bin/run_ingestion.py: Python launcher (no SparkSession). Parses `conf/jobs.config`, builds and executes a child `spark3-submit` for the actual ingestion job.
- src/dds_framework/ingestion_job.py: The real PySpark program that initializes Spark and performs table creation/insert logic.
- bin/run_ingestion.sh: Legacy POSIX launcher retained for reference; superseded by the Python launcher.

## Why this structure
- Single command for users: `spark3-submit .../bin/run_ingestion.py --job-name <name>`
- Two separate Spark apps: the launcher only orchestrates; the job does all Spark work.
- Clear separation of concerns and easier testing (`--dry-run` to print the child command).

## Running

```bash
# Print the child spark3-submit command without executing
spark3-submit bin/run_ingestion.py --job-name <your_job> --dry-run

# Execute the ingestion job via the launcher
spark3-submit bin/run_ingestion.py --job-name <your_job>
```

Notes:
- The launcher reads `conf/jobs.config`, merges `[common]` + `[jobs.<your_job>]`, and passes:
  - submit-time settings via `--conf`
  - extra raw options via `spark_options` lines
  - program arguments and `--spark-conf key=value` pairs to the PySpark job
- Logs are written under `logs/` as `<job>_shell_*.log` (launcher) and `<job>_spark_*.log` (job).

## Configuration
Put shared and job-specific config in `conf/jobs.config` using sections:

```
[common]
submit_conf.spark.yarn.maxAppAttempts=1
spark_options=--files conf/some.json
spark_conf.spark.sql.shuffle.partitions=200

[jobs.sample]
view_name=db.sample_view
target_table=db.sample_table
load_method=append
user_name=abcd123
```

## Development
- Keep the two scripts separate (do not import one in the other).
- Prefer client deploy mode for the launcher if it needs to execute `spark3-submit`.
- The ingestion job supports both append and overwrite with partition-aware behavior.

### Temporary dry-run harness (safe to remove)
For quick validation without Spark installed, a small harness exists under `tests/dry_run/`:

- `tests/dry_run/jobs.config` — sample config
- `tests/dry_run/run_dry.py` — runs the launcher with `--dry-run` and prints the constructed `spark3-submit` command

Run:

```bash
python3 tests/dry_run/run_dry.py
```

Remove by deleting the `tests/dry_run` folder if not needed.
