"""Audit capture for DDS ingestion jobs.

Writes a single audit row per run into a Hive/Spark table partitioned by biz_dt.
Data captured:
  - user_name (from Spark: sparkContext.sparkUser)
  - job_name
  - start_ts (timestamp)
  - end_ts (timestamp)
  - duration_sec (long)
  - view_name
  - target_table
  - num_read (long)
  - num_loaded (long)
  - configs (JSON string of configs passed)
  - biz_dt (string, yyyy-MM-dd) used as partition column

The table is created if it does not exist, using USING PARQUET and PARTITIONED BY (biz_dt).
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession


def _set_dynamic_partitioning(spark: SparkSession) -> None:
    spark.sql("SET hive.exec.dynamic.partition=true")
    spark.sql("SET hive.exec.dynamic.partition.mode=nonstrict")


def _ensure_audit_table(spark: SparkSession, table_name: str) -> None:
    """Create the audit table if it does not exist, partitioned by biz_dt."""
    ddl = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
      job_name STRING,
      user_name STRING,
      start_ts TIMESTAMP,
      end_ts TIMESTAMP,
      duration_sec BIGINT,
      view_name STRING,
      target_table STRING,
      num_read BIGINT,
      num_loaded BIGINT,
      configs STRING
    ) USING PARQUET
    PARTITIONED BY (biz_dt STRING)
    """
    spark.sql(ddl)


def _parse_kv_list(pairs: list[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for entry in pairs:
        if "=" not in entry:
            raise ValueError(f"Invalid --conf '{entry}', expected key=value")
        k, v = entry.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _parse_ts(ts: str) -> datetime:
    # Accept ISO-8601 with or without 'T', with optional seconds
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(ts, fmt)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(ts)
    except Exception as e:
        raise ValueError(f"Unrecognized timestamp format: {ts}") from e


def capture_audit(
    spark: SparkSession,
    *,
    audit_table: str,
    job_name: str,
    view_name: str,
    target_table: str,
    start_time: datetime,
    end_time: datetime,
    num_read: int,
    num_loaded: int,
    configs: Optional[Dict[str, Any]] = None,
) -> None:
    """Write a single audit row to the audit table via pure SQL, creating the table if needed."""
    _set_dynamic_partitioning(spark)
    _ensure_audit_table(spark, audit_table)

    user_name = spark.sparkContext.sparkUser()
    duration_sec = int((end_time - start_time).total_seconds())
    configs_json = json.dumps(configs or {}, sort_keys=True)

    def _lit(s: str) -> str:
        return "'" + s.replace("'", "''") + "'"

    # Use pure SQL with literals; cast timestamps from strings for portability
    start_s = start_time.strftime("%Y-%m-%d %H:%M:%S")
    end_s = end_time.strftime("%Y-%m-%d %H:%M:%S")
    sql = f"""
    INSERT INTO {audit_table}
    SELECT
      {_lit(job_name)} AS job_name,
      {_lit(user_name)} AS user_name,
      to_timestamp({_lit(start_s)}) AS start_ts,
      to_timestamp({_lit(end_s)}) AS end_ts,
      {int(duration_sec)} AS duration_sec,
      {_lit(view_name)} AS view_name,
      {_lit(target_table)} AS target_table,
      {int(num_read)} AS num_read,
      {int(num_loaded)} AS num_loaded,
      {_lit(configs_json)} AS configs,
      date_format(current_date(), 'yyyy-MM-dd') AS biz_dt
    """
    spark.sql(sql)


def _parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Capture a single DDS ingestion audit row")
    p.add_argument("--audit-table", default="default.dds_ingestion_audit")
    p.add_argument("--job-name", required=True)
    p.add_argument("--view-name", required=True)
    p.add_argument("--target-table", required=True)
    p.add_argument("--start-time", required=True, help="Start timestamp, e.g. 2025-10-21T10:00:00")
    p.add_argument("--end-time", required=True, help="End timestamp, e.g. 2025-10-21T10:05:30")
    p.add_argument("--num-read", required=True, type=int)
    p.add_argument("--num-loaded", required=True, type=int)
    p.add_argument("--conf", action="append", default=[], help="key=value; can repeat")
    p.add_argument("--config-json", help="Path to JSON file with additional configs")
    p.add_argument("--app-name", default=None, help="Optional Spark app name override")
    return p.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = _parse_args(argv or [])

    # Build Spark
    app_name = args.app_name or f"dds_audit_capture_{args.job_name}"
    spark = SparkSession.builder.appName(app_name).enableHiveSupport().getOrCreate()

    # Merge configs
    cfg = _parse_kv_list(args.conf)
    if args.config_json:
        with open(args.config_json, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))

    start_ts = _parse_ts(args.start_time)
    end_ts = _parse_ts(args.end_time)

    try:
        capture_audit(
            spark,
            audit_table=args.audit_table,
            job_name=args.job_name,
            view_name=args.view_name,
            target_table=args.target_table,
            start_time=start_ts,
            end_time=end_ts,
            num_read=args.num_read,
            num_loaded=args.num_loaded,
            configs=cfg,
        )
        return 0
    except Exception:
        # Best-effort audit; print to stderr for operator visibility
        import traceback, sys as _sys

        traceback.print_exc(file=_sys.stderr)
        return 1
    finally:
        spark.stop()


if __name__ == "__main__":
    raise SystemExit(main())
