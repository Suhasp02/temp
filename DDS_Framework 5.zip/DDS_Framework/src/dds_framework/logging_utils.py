"""Minimal logging utilities for DDS framework.

Provides setup_logging() that returns a standard Python logger configured
with optional file output and level control. Compatible with calls like
logger.info(msg, extra={...}) and logger.exception(...).
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path
from typing import Optional


def setup_logging(
    level: str = "INFO",
    job_name: str = "job",
    user_name: str = "user",
    target_table: str = "table",
    component: str = "app",
    log_file: Optional[str] = None,
) -> logging.Logger:
    logger = logging.getLogger(f"dds.{job_name}")
    if logger.handlers:
        # Already configured
        logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        return logger

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    formatter = logging.Formatter(
        fmt=(
            "%(asctime)s | %(levelname)s | job=%(job_name)s user=%(user_name)s target=%(target_table)s component=%(component)s | "
            "%(name)s | %(message)s"
        ),
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Stream handler
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    # File handler if provided
    if log_file:
        try:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(formatter)
            logger.addHandler(fh)
        except Exception:  # pragma: no cover - file permission issues
            logger.warning("Failed to attach file handler for log_file=%s", log_file)

    # Add contextual defaults using LoggerAdapter-like behavior through filters
    class _ContextFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:  # type: ignore[override]
            if not hasattr(record, "job_name"):
                record.job_name = job_name
            if not hasattr(record, "user_name"):
                record.user_name = user_name
            if not hasattr(record, "target_table"):
                record.target_table = target_table
            if not hasattr(record, "component"):
                record.component = component
            return True

    logger.addFilter(_ContextFilter())
    logger.propagate = False
    return logger
