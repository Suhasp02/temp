-- Hive/Spark SQL DDL for a lightweight date dimension the ingestion jobs will use
-- to resolve the latest business date per src_system and site_id without scanning
-- massive source views.
--
-- Notes
-- - External table so data location is controlled outside the metastore lifecycle
-- - Partitioned by (src_system, site_id) for cheap pruning on lookups
-- - biz_dt stored as 'yyyy-MM-dd' string; MAX() is lexicographically consistent
-- - Keep the schema minimal; add attributes as needed
-- - Adjust LOCATION to your cluster path

CREATE DATABASE IF NOT EXISTS dds_meta;

CREATE EXTERNAL TABLE IF NOT EXISTS dds_meta.date_dim (
  biz_dt          STRING COMMENT 'Business date in yyyy-MM-dd',
  date_key        INT    COMMENT 'yyyymmdd as integer for joins/index',
  year            INT,
  quarter         INT,
  month           INT,
  day             INT,
  day_of_week     INT    COMMENT '1=Mon .. 7=Sun',
  is_weekend      BOOLEAN
)
PARTITIONED BY (
  src_system      STRING,
  site_id         STRING
)
STORED AS PARQUET
LOCATION 'hdfs:///data/dds_meta/date_dim'  -- CHANGE_ME if needed
TBLPROPERTIES (
  'external.table.purge'='true'
);

-- After the first load, run (if you loaded files directly under LOCATION)
--   MSCK REPAIR TABLE dds_meta.date_dim;
-- If you load via Spark with dynamic partitions, REPAIR is not required.
