# Date Dimension Setup

This project uses a lightweight date dimension to resolve the latest `biz_dt` per `src_system` and `site_id` without scanning large source views.

## Artifacts
- `docs/date_dim_external_table.sql` — Hive/Spark SQL DDL to create the external table `dds_meta.date_dim`.
- `bin/load_date_dim_2025.py` — PySpark script that inserts rows for all dates in 2025 for a made-up set of `src_system`/`site_id` values.

## How to create the table
Run the DDL once (adjust LOCATION as needed):

```sql
-- open in beeline or spark-sql
!run docs/date_dim_external_table.sql;
```

## How to load data for 2025
Customize the `SRC_SYSTEMS` and `SITE_IDS` arrays at the top of the loader script as needed, then run with Spark:

```bash
spark-submit --master yarn --deploy-mode client \
  bin/load_date_dim_2025.py
```

This will append partitioned rows into `dds_meta.date_dim` for each combination of `src_system` x `site_id` across every date in 2025.

## How ingestion uses it
When a job is launched without an explicit `biz_dt`, the ingestion logic now resolves `biz_dt` from the date dimension:

```sql
SELECT MAX(biz_dt)
FROM dds_meta.date_dim
WHERE src_system IN (...) AND site_id IN (...);
```

Ensure your orchestration increments the date dimension daily so jobs always pick up the current date.
