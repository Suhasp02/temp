"""Schema reconciliation helpers."""
from __future__ import annotations

from typing import List, Tuple

from pyspark.sql import DataFrame, SparkSession, functions as F

from . import hive_utils, logging_utils


def _normalize_columns(df: DataFrame) -> DataFrame:
    normalized_df = df
    for col_name in df.columns:
        lower_col = col_name.lower()
        if col_name != lower_col:
            normalized_df = normalized_df.withColumnRenamed(col_name, lower_col)
    return normalized_df


def align_dataframe_with_table(
    spark: SparkSession,
    df: DataFrame,
    table_name: str,
) -> Tuple[DataFrame, List[Tuple[str, str]]]:
    """Return a DataFrame aligned to the table schema and list of new columns added."""
    logger = logging_utils.get_logger()
    normalized_df = _normalize_columns(df)

    table_schema = hive_utils.get_table_schema(spark, table_name)
    table_columns = hive_utils.get_column_map(table_schema)

    df_schema = normalized_df.schema
    df_columns = hive_utils.get_column_map(df_schema)

    missing_in_df = [field for name, field in table_columns.items() if name not in df_columns]

    for field in missing_in_df:
        normalized_df = normalized_df.withColumn(field.name, F.lit(None).cast(field.dataType))
        logger.info("Added NULL filler column to DataFrame", extra={"column": field.name})

    missing_in_table = [field for name, field in df_columns.items() if name not in table_columns]

    added_columns: List[Tuple[str, str]] = []
    if missing_in_table:
        add_defs = [(field.name, field.dataType) for field in missing_in_table]
        hive_utils.add_columns_to_table(spark, table_name, add_defs)
        added_columns = [(field.name, field.dataType.simpleString()) for field in missing_in_table]

    final_order: List[str] = [field.name for field in table_schema]
    final_order.extend(field.name for field in missing_in_table)
    normalized_df = normalized_df.select(*final_order)

    return normalized_df, added_columns
