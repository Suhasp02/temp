"""Hive helper utilities."""
from __future__ import annotations

from typing import Dict, Iterable, List, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import DataType, StructField, StructType

from . import logging_utils


def table_exists(spark: SparkSession, table_name: str) -> bool:
    return spark.catalog.tableExists(table_name)


def get_table_schema(spark: SparkSession, table_name: str) -> StructType:
    return spark.table(table_name).schema


def get_column_map(schema: StructType) -> Dict[str, StructField]:
    return {field.name.lower(): field for field in schema}


def spark_type_to_hive(data_type: DataType) -> str:
    return data_type.simpleString()


def create_external_table(
    spark: SparkSession,
    df: DataFrame,
    table_name: str,
    location: str,
    partition_columns: Iterable[str] | None = None,
) -> None:
    logger = logging_utils.get_logger()
    writer = df.write.mode("overwrite").format("parquet").option("path", location)
    if partition_columns:
        writer = writer.partitionBy(*partition_columns)
    writer.saveAsTable(table_name)
    spark.sql(f"ALTER TABLE {table_name} SET TBLPROPERTIES('EXTERNAL'='TRUE')")
    logger.info("Created external table", extra={"location": location})


def add_columns_to_table(
    spark: SparkSession,
    table_name: str,
    columns: List[Tuple[str, DataType]],
) -> None:
    if not columns:
        return
    logger = logging_utils.get_logger()
    column_defs = ", ".join(f"{name} {spark_type_to_hive(dtype)}" for name, dtype in columns)
    spark.sql(f"ALTER TABLE {table_name} ADD COLUMNS ({column_defs})")
    logger.info("Added columns to table", extra={"columns": [name for name, _ in columns]})
