"""Filter helpers for enforcing ingestion predicates."""
from __future__ import annotations

from typing import Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from . import logging_utils


def apply_mandatory_filters(
    spark: SparkSession,
    view_name: str,
    src_system: Optional[str],
    site_id: Optional[str],
    biz_dt: Optional[str],
) -> Tuple[DataFrame, Optional[str]]:
    """Return the filtered DataFrame and resolved biz_dt."""
    logger = logging_utils.get_logger()

    df = spark.table(view_name)

    if src_system:
        df = df.filter(F.col("src_system") == F.lit(src_system))
    if site_id:
        df = df.filter(F.col("site_id") == F.lit(site_id))

    resolved_biz_dt = biz_dt
    if not resolved_biz_dt:
        logger.info("biz_dt not provided; resolving using MAX(biz_dt) from view")
        max_row = df.agg(F.max(F.col("biz_dt")).alias("max_biz_dt")).collect()
        if not max_row or max_row[0]["max_biz_dt"] is None:
            raise ValueError("Unable to resolve biz_dt from view; no rows found")
        resolved_biz_dt = str(max_row[0]["max_biz_dt"])

    df = df.filter(F.col("biz_dt") == F.lit(resolved_biz_dt))
    return df, resolved_biz_dt
