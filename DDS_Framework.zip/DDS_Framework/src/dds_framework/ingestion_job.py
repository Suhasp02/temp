"""Main entrypoint for DDS ingestion."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict

from pyspark.sql import SparkSession

if __package__ is None or __package__ == "":  # pragma: no cover - executed in script mode
    CURRENT_DIR = Path(__file__).resolve().parent
    PACKAGE_ROOT = CURRENT_DIR.parent
    if str(PACKAGE_ROOT) not in sys.path:
        sys.path.insert(0, str(PACKAGE_ROOT))
    from dds_framework import audit, config, filters, hive_utils, logging_utils, schema_manager
else:  # pragma: no cover
    from . import audit, config, filters, hive_utils, logging_utils, schema_manager


def parse_spark_conf(values: list[str]) -> Dict[str, str]:
    overrides: Dict[str, str] = {}
    for entry in values:
        if "=" not in entry:
            raise ValueError(f"Invalid --spark-conf entry '{entry}'. Expected key=value format.")
        key, value = entry.split("=", 1)
        overrides[key.strip()] = value.strip()
    return overrides


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DDS PySpark ingestion framework")
    parser.add_argument("--view-name", required=True, help="Fully qualified Hive view to read from")
    parser.add_argument("--target-table", required=True, help="Target Hive table to load")
    parser.add_argument(
        "--load-method",
        required=True,
        choices=["append", "overwrite"],
        help="Spark write mode",
    )
    parser.add_argument("--job-name", required=True, help="Logical job identifier")
    parser.add_argument("--user-name", required=True, help="Submitting analyst user ID")

    parser.add_argument("--src-system", help="Source system filter value")
    parser.add_argument("--site-id", help="Site identifier filter value")
    parser.add_argument("--biz-dt", help="Business date filter value")

    parser.add_argument("--config", help="Path to YAML config file with defaults")
    parser.add_argument("--target-location", help="Override external table location path")
    parser.add_argument("--audit-table", help="Override audit table name")
    parser.add_argument("--audit-mode", help="Override audit table write mode")

    parser.add_argument("--log-level", default="INFO", help="Python logging level")
    parser.add_argument("--log-file", help="Path to log file for Python logger")

    parser.add_argument("--spark-executor-instances", type=int)
    parser.add_argument("--spark-executor-memory", help="Executor memory, e.g. 4g")
    parser.add_argument("--spark-driver-memory", help="Driver memory, e.g. 2g")
    parser.add_argument("--spark-executor-cores", type=int)
    parser.add_argument(
        "--spark-conf",
        action="append",
        default=[],
        help="Additional Spark conf in key=value format. Can be repeated.",
    )

    return parser.parse_args(argv)


def build_spark_session(configuration: Dict[str, Any], job_name: str, extra_conf: Dict[str, str]) -> SparkSession:
    builder = SparkSession.builder.appName(config.app_name(configuration, job_name)).enableHiveSupport()
    for key, value in config.build_spark_conf(configuration).items():
        builder = builder.config(key, value)
    for key, value in extra_conf.items():
        builder = builder.config(key, value)
    return builder.getOrCreate()


def run(argv: list[str]) -> int:
    args = parse_args(argv)

    override_payload: Dict[str, Dict] = {"filters": {}}

    if args.spark_executor_instances is not None:
        override_payload.setdefault("spark", {})["executor_instances"] = args.spark_executor_instances
    if args.spark_executor_memory:
        override_payload.setdefault("spark", {})["executor_memory"] = args.spark_executor_memory
    if args.spark_driver_memory:
        override_payload.setdefault("spark", {})["driver_memory"] = args.spark_driver_memory
    if args.spark_executor_cores is not None:
        override_payload.setdefault("spark", {})["executor_cores"] = args.spark_executor_cores
    if args.audit_table:
        override_payload.setdefault("audit", {})["table"] = args.audit_table
    if args.audit_mode:
        override_payload.setdefault("audit", {})["mode"] = args.audit_mode

    if args.src_system:
        override_payload["filters"]["src_system"] = args.src_system
    if args.site_id:
        override_payload["filters"]["site_id"] = args.site_id
    if args.biz_dt:
        override_payload["filters"]["biz_dt"] = args.biz_dt

    runtime_config = config.resolve_runtime_config(args.config, override_payload)

    logger = logging_utils.setup_logging(
        level=args.log_level,
        job_name=args.job_name,
        user_name=args.user_name,
        target_table=args.target_table,
        log_file=args.log_file,
    )

    spark_conf_overrides = parse_spark_conf(args.spark_conf)
    spark = build_spark_session(runtime_config, args.job_name, spark_conf_overrides)

    audit_conf = config.audit_settings(runtime_config)

    filter_defaults = config.filter_defaults(runtime_config)
    resolved_biz_dt = filter_defaults.get("biz_dt")

    try:
        df, resolved_biz_dt = filters.apply_mandatory_filters(
            spark=spark,
            view_name=args.view_name,
            src_system=filter_defaults.get("src_system"),
            site_id=filter_defaults.get("site_id"),
            biz_dt=filter_defaults.get("biz_dt"),
        )
        row_count = df.count()
        logger.info("Fetched data from view", extra={"row_count": row_count, "biz_dt": resolved_biz_dt})

        if not hive_utils.table_exists(spark, args.target_table):
            location = config.external_table_path(runtime_config, args.target_table, args.target_location)
            hive_utils.create_external_table(
                spark=spark,
                df=df,
                table_name=args.target_table,
                location=location,
                partition_columns=config.partition_columns(runtime_config),
            )
            logger.info("Created target table", extra={"location": location})
        else:
            aligned_df, added_columns = schema_manager.align_dataframe_with_table(
                spark=spark,
                df=df,
                table_name=args.target_table,
            )
            overwrite = args.load_method == "overwrite"
            aligned_df.write.insertInto(args.target_table, overwrite=overwrite)
            if added_columns:
                logger.info("Added new columns to target table", extra={"columns": added_columns})

        audit.log_success(
            spark=spark,
            table_name=audit_conf["table"],
            mode=audit_conf["mode"],
            job_name=args.job_name,
            user_name=args.user_name,
            target_table=args.target_table,
            source_view=args.view_name,
            load_method=args.load_method,
            row_count=row_count,
            biz_dt=resolved_biz_dt,
        )
        logger.info("Ingestion completed successfully", extra={"row_count": row_count})
        return 0
    except Exception as exc:  # pylint: disable=broad-except
        logger.exception("Ingestion failed")
        audit.log_failure(
            spark=spark,
            table_name=audit_conf["table"],
            mode=audit_conf["mode"],
            job_name=args.job_name,
            user_name=args.user_name,
            target_table=args.target_table,
            source_view=args.view_name,
            load_method=args.load_method,
            error_message=str(exc),
            biz_dt=resolved_biz_dt,
        )
        return 1
    finally:
        spark.stop()


def main() -> None:
    sys.exit(run(sys.argv[1:]))
