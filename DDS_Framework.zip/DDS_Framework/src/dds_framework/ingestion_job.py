"""Main entrypoint for DDS ingestion."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List

from pyspark.sql import SparkSession

if __package__ is None or __package__ == "":  # pragma: no cover - executed in script mode
    CURRENT_DIR = Path(__file__).resolve().parent
    PACKAGE_ROOT = CURRENT_DIR.parent
    if str(PACKAGE_ROOT) not in sys.path:
        sys.path.insert(0, str(PACKAGE_ROOT))
    from dds_framework import filters, hive_utils, logging_utils, schema_manager
else:  # pragma: no cover
    from . import filters, hive_utils, logging_utils, schema_manager


def parse_spark_conf(values: list[str]) -> Dict[str, str]:
    overrides: Dict[str, str] = {}
    for entry in values:
        if "=" not in entry:
            raise ValueError(f"Invalid --spark-conf entry '{entry}'. Expected key=value format.")
        key, value = entry.split("=", 1)
        overrides[key.strip()] = value.strip()
    return overrides


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DDS PySpark ingestion framework")
    parser.add_argument("--view-name", required=True, help="Fully qualified Hive view to read from")
    parser.add_argument("--target-table", required=True, help="Target Hive table to load")
    parser.add_argument(
        "--load-method",
        required=True,
        choices=["append", "overwrite"],
        help="Spark write mode",
    )
    parser.add_argument("--job-name", required=True, help="Logical job identifier")
    parser.add_argument("--user-name", required=True, help="Submitting analyst user ID")

    parser.add_argument("--src-system", help="Source system filter value")
    parser.add_argument("--site-id", help="Site identifier filter value")
    parser.add_argument("--biz-dt", help="Business date filter value")

    # No external config file; INI is handled by the shell wrapper
    parser.add_argument("--target-location", help="External table location path (required when creating table)")

    parser.add_argument("--log-level", default="INFO", help="Python logging level")
    parser.add_argument("--log-file", help="Path to log file for Python logger")

    parser.add_argument("--spark-executor-instances", type=int)
    parser.add_argument("--spark-executor-memory", help="Executor memory, e.g. 4g")
    parser.add_argument("--spark-driver-memory", help="Driver memory, e.g. 2g")
    parser.add_argument("--spark-executor-cores", type=int)
    parser.add_argument(
        "--spark-conf",
        action="append",
        default=[],
        help="Additional Spark conf in key=value format. Can be repeated.",
    )

    return parser.parse_args(argv)


def build_spark_session(job_name: str, extra_conf: Dict[str, str]) -> SparkSession:
    builder = SparkSession.builder.appName(f"dds_ingestion_{job_name}").enableHiveSupport()
    for key, value in extra_conf.items():
        builder = builder.config(key, value)
    return builder.getOrCreate()


def run(argv: list[str]) -> int:
    args = parse_args(argv)

    logger = logging_utils.setup_logging(
        level=args.log_level,
        job_name=args.job_name,
        user_name=args.user_name,
        target_table=args.target_table,
        log_file=args.log_file,
    )
    # Build Spark conf overrides from CLI only
    spark_conf_overrides = parse_spark_conf(args.spark_conf)
    if args.spark_executor_instances is not None:
        spark_conf_overrides["spark.executor.instances"] = str(args.spark_executor_instances)
    if args.spark_executor_memory:
        spark_conf_overrides["spark.executor.memory"] = args.spark_executor_memory
    if args.spark_driver_memory:
        spark_conf_overrides["spark.driver.memory"] = args.spark_driver_memory
    if args.spark_executor_cores is not None:
        spark_conf_overrides["spark.executor.cores"] = str(args.spark_executor_cores)

    spark = build_spark_session(args.job_name, spark_conf_overrides)

    resolved_biz_dt = args.biz_dt

    try:
        df, resolved_biz_dt = filters.apply_mandatory_filters(
            spark=spark,
            view_name=args.view_name,
            src_system=args.src_system,
            site_id=args.site_id,
            biz_dt=args.biz_dt,
        )
        row_count = df.count()
        logger.info("Fetched data from view", extra={"row_count": row_count, "biz_dt": resolved_biz_dt})

        if not hive_utils.table_exists(spark, args.target_table):
            if not args.target_location:
                raise ValueError("target_location must be provided to create a new external table")
            location = args.target_location
            # Partition columns are always site_id and biz_dt if present in the data
            desired_parts: List[str] = ["site_id", "biz_dt"]
            present_parts = [c for c in desired_parts if c in df.columns]
            hive_utils.create_external_table(
                spark=spark,
                df=df,
                table_name=args.target_table,
                location=location,
                partition_columns=present_parts if present_parts else None,
            )
            logger.info("Created target table", extra={"location": location})
        else:
            aligned_df, added_columns = schema_manager.align_dataframe_with_table(
                spark=spark,
                df=df,
                table_name=args.target_table,
            )
            overwrite = args.load_method == "overwrite"
            aligned_df.write.insertInto(args.target_table, overwrite=overwrite)
            if added_columns:
                logger.info("Added new columns to target table", extra={"columns": added_columns})

        logger.info("Ingestion completed successfully", extra={"row_count": row_count})
        return 0
    except Exception as exc:  # pylint: disable=broad-except
        logger.exception("Ingestion failed")
        return 1
    finally:
        spark.stop()


def main() -> None:
    sys.exit(run(sys.argv[1:]))
