"""Configuration utilities for the DDS PySpark ingestion framework."""
from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


DEFAULT_CONFIG: Dict[str, Any] = {
    "spark": {
        "app_name_prefix": "dds_ingestion",
        "executor_instances": 4,
        "executor_memory": "4g",
        "driver_memory": "2g",
        "executor_cores": 2,
        "dynamic_allocation": False,
        "shuffle_partitions": 200,
    },
    "hive": {
        "database": "default",
        "external_base_path": "hdfs:///data/external/dds",
        "partition_columns": ["biz_dt"],
    },
    "audit": {
        "table": "default.dds_ingestion_audit",
        "mode": "append",
    },
    "filters": {
        "src_system": None,
        "site_id": None,
        "biz_dt": None,
    },
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_defaults() -> Dict[str, Any]:
    return copy.deepcopy(DEFAULT_CONFIG)


def load_from_file(config_path: Optional[str]) -> Dict[str, Any]:
    configuration = load_defaults()
    if not config_path:
        return configuration
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found at {config_path}")
    with path.open("r", encoding="utf-8") as handle:
        file_conf = yaml.safe_load(handle) or {}
    return _deep_merge(configuration, file_conf)


def resolve_runtime_config(config_path: Optional[str], overrides: Dict[str, Any]) -> Dict[str, Any]:
    configuration = load_from_file(config_path)
    if overrides:
        configuration = _deep_merge(configuration, overrides)
    return configuration


def build_spark_conf(configuration: Dict[str, Any]) -> Dict[str, Any]:
    spark_conf = configuration.get("spark", {})
    conf = {
        "spark.executor.instances": spark_conf.get("executor_instances"),
        "spark.executor.memory": spark_conf.get("executor_memory"),
        "spark.driver.memory": spark_conf.get("driver_memory"),
        "spark.executor.cores": spark_conf.get("executor_cores"),
        "spark.sql.shuffle.partitions": spark_conf.get("shuffle_partitions"),
    }
    if spark_conf.get("dynamic_allocation"):
        conf.update(
            {
                "spark.dynamicAllocation.enabled": "true",
                "spark.shuffle.service.enabled": "true",
            }
        )
    else:
        conf["spark.dynamicAllocation.enabled"] = "false"
    return {key: value for key, value in conf.items() if value is not None}


def app_name(configuration: Dict[str, Any], job_name: str) -> str:
    prefix = configuration.get("spark", {}).get("app_name_prefix", "dds_ingestion")
    return f"{prefix}_{job_name}"


def audit_settings(configuration: Dict[str, Any]) -> Dict[str, Any]:
    audit_conf = configuration.get("audit", {})
    return {
        "table": audit_conf.get("table", "default.dds_ingestion_audit"),
        "mode": audit_conf.get("mode", "append"),
    }


def filter_defaults(configuration: Dict[str, Any]) -> Dict[str, Optional[str]]:
    filters_conf = configuration.get("filters", {})
    return {
        "src_system": filters_conf.get("src_system"),
        "site_id": filters_conf.get("site_id"),
        "biz_dt": filters_conf.get("biz_dt"),
    }


def external_table_path(
    configuration: Dict[str, Any],
    table_name: str,
    explicit_path: Optional[str] = None,
) -> str:
    if explicit_path:
        return explicit_path
    base_path = configuration.get("hive", {}).get("external_base_path")
    if not base_path:
        raise ValueError("External table base path is not configured")
    normalized = table_name.replace(".", "/")
    return os.path.join(base_path.rstrip("/"), normalized)


def partition_columns(configuration: Dict[str, Any]) -> Optional[list[str]]:
    partitions = configuration.get("hive", {}).get("partition_columns")
    if partitions:
        return [col.lower() for col in partitions]
    return None


def hive_database(configuration: Dict[str, Any]) -> str:
    return configuration.get("hive", {}).get("database", "default")
