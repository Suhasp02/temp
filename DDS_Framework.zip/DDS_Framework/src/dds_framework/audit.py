"""Audit logging utilities."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit

from . import logging_utils


AUDIT_STATUS_SUCCESS = "SUCCESS"
AUDIT_STATUS_FAILED = "FAILED"


def _build_record(
    job_name: str,
    user_name: str,
    target_table: str,
    source_view: str,
    load_method: str,
    status: str,
    row_count: Optional[int],
    biz_dt: Optional[str],
    additional_info: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "job_name": job_name,
        "user_name": user_name,
        "target_table": target_table,
        "source_view": source_view,
        "load_method": load_method,
        "status": status,
        "row_count": row_count,
        "biz_dt": biz_dt,
        "event_ts": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "details": additional_info or {},
    }


def log_audit_event(
    spark: SparkSession,
    table_name: str,
    mode: str,
    job_name: str,
    user_name: str,
    target_table: str,
    source_view: str,
    load_method: str,
    status: str,
    row_count: Optional[int],
    biz_dt: Optional[str],
    additional_info: Optional[Dict[str, Any]] = None,
) -> None:
    """Write a single audit record to Hive."""
    record = _build_record(
        job_name=job_name,
        user_name=user_name,
        target_table=target_table,
        source_view=source_view,
        load_method=load_method,
        status=status,
        row_count=row_count,
        biz_dt=biz_dt,
        additional_info=additional_info,
    )

    df = spark.createDataFrame([record])
    df = df.select(
        lit(record["job_name"]).alias("job_name"),
        lit(record["user_name"]).alias("user_name"),
        lit(record["target_table"]).alias("target_table"),
        lit(record["source_view"]).alias("source_view"),
        lit(record["load_method"]).alias("load_method"),
        lit(record["status"]).alias("status"),
        lit(record["row_count"]).alias("row_count"),
        lit(record["biz_dt"]).alias("biz_dt"),
        lit(record["event_ts"]).alias("event_ts"),
        lit(str(record["details"])).alias("details"),
    )
    df.write.mode(mode).format("hive").saveAsTable(table_name)

    logging_utils.get_logger().info("Audit record written", extra={"status": status})


def log_success(
    spark: SparkSession,
    table_name: str,
    mode: str,
    job_name: str,
    user_name: str,
    target_table: str,
    source_view: str,
    load_method: str,
    row_count: int,
    biz_dt: Optional[str],
) -> None:
    log_audit_event(
        spark=spark,
        table_name=table_name,
        mode=mode,
        job_name=job_name,
        user_name=user_name,
        target_table=target_table,
        source_view=source_view,
        load_method=load_method,
        status=AUDIT_STATUS_SUCCESS,
        row_count=row_count,
        biz_dt=biz_dt,
    )


def log_failure(
    spark: SparkSession,
    table_name: str,
    mode: str,
    job_name: str,
    user_name: str,
    target_table: str,
    source_view: str,
    load_method: str,
    error_message: str,
    biz_dt: Optional[str],
) -> None:
    log_audit_event(
        spark=spark,
        table_name=table_name,
        mode=mode,
        job_name=job_name,
        user_name=user_name,
        target_table=target_table,
        source_view=source_view,
        load_method=load_method,
        status=AUDIT_STATUS_FAILED,
        row_count=None,
        biz_dt=biz_dt,
        additional_info={"error": error_message},
    )
