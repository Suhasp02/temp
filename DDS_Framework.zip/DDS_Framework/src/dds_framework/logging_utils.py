"""Logging helpers for the DDS framework."""
from __future__ import annotations

import logging
from typing import Optional


LOG_FORMAT = (
    "%(asctime)s | %(levelname)s | %(name)s | job=%(job_name)s | user=%(user_name)s | "
    "table=%(target_table)s | %(message)s"
)
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_LOGGER_ADAPTER: Optional[logging.LoggerAdapter] = None


def setup_logging(
    level: str,
    job_name: str,
    user_name: str,
    target_table: str,
    log_file: Optional[str] = None,
    logger_name: str = "dds",
) -> logging.LoggerAdapter:
    """Configure application logging and return a logger adapter with context."""
    global _LOGGER_ADAPTER  # pylint: disable=global-statement

    logging_level = getattr(logging, level.upper(), logging.INFO)
    base_logger = logging.getLogger(logger_name)
    if base_logger.handlers:
        for existing in list(base_logger.handlers):
            base_logger.removeHandler(existing)
            existing.close()

    formatter = logging.Formatter(LOG_FORMAT, DATE_FORMAT)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    base_logger.addHandler(stream_handler)

    if log_file:
        file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
        file_handler.setFormatter(formatter)
        base_logger.addHandler(file_handler)

    base_logger.setLevel(logging_level)
    base_logger.propagate = False

    context = {
        "job_name": job_name,
        "user_name": user_name,
        "target_table": target_table,
    }
    _LOGGER_ADAPTER = logging.LoggerAdapter(base_logger, context)
    return _LOGGER_ADAPTER


def get_logger() -> logging.LoggerAdapter:
    """Return the configured logger adapter."""
    if _LOGGER_ADAPTER is None:
        raise RuntimeError("Logging has not been initialised. Call setup_logging first.")
    return _LOGGER_ADAPTER
