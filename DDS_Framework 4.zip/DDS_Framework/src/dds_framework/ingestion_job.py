"""PySpark job entrypoint: DDS ingestion (CDP/Hive).

- Requires: --src-system and --site-id (comma-separated supported)
- Derives submitting user from Spark (sparkContext.sparkUser)
- Supports append/overwrite; CTAS on first load; dynamic partitions
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import SparkSession

# Local import for logging utility whether run as package or script
if __package__ is None or __package__ == "":  # pragma: no cover
    CURRENT_DIR = Path(__file__).resolve().parent
    PACKAGE_ROOT = CURRENT_DIR.parent
    if str(PACKAGE_ROOT) not in sys.path:
        sys.path.insert(0, str(PACKAGE_ROOT))
    from dds_framework import logging_utils
    from dds_framework import audit_capture
else:  # pragma: no cover
    from . import logging_utils
    from . import audit_capture

# Audit table pre-created in Hive
AUDIT_TABLE = "default.dds_ingestion_audit"
# Central date dimension used to derive latest business date when not provided
DATE_DIM_TABLE = "dds_meta.date_dim"


def parse_spark_conf(values: List[str]) -> Dict[str, str]:
    conf: Dict[str, str] = {}
    for entry in values:
        if "=" not in entry:
            raise ValueError(f"Invalid --spark-conf '{entry}', expected key=value")
        k, v = entry.split("=", 1)
        conf[k.strip()] = v.strip()
    return conf


def parse_args(argv: List[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="DDS PySpark ingestion")
    p.add_argument("--view-name", required=True)
    p.add_argument("--target-table", required=True)
    p.add_argument("--load-method", required=True, choices=["append", "overwrite"])
    p.add_argument("--job-name", required=True)
    p.add_argument("--src-system", required=True, help="comma-separated values allowed")
    p.add_argument("--site-id", required=True, help="comma-separated values allowed")
    p.add_argument("--biz-dt")
    p.add_argument("--log-level", default="INFO")
    p.add_argument("--log-file")
    p.add_argument("--spark-executor-instances", type=int)
    p.add_argument("--spark-executor-memory")
    p.add_argument("--spark-driver-memory")
    p.add_argument("--spark-executor-cores", type=int)
    p.add_argument("--spark-conf", action="append", default=[])
    return p.parse_args(argv)


def build_spark_session(job_name: str, extra_conf: Dict[str, str]) -> SparkSession:
    builder = SparkSession.builder.appName(f"dds_ingestion_{job_name}").enableHiveSupport()
    for k, v in extra_conf.items():
        builder = builder.config(k, v)
    return builder.getOrCreate()


def _sql_literal(v: str) -> str:
    return "'" + v.replace("'", "''") + "'"


def _qid(n: str) -> str:
    return f"`{n}`"


def _exec_sql(spark: SparkSession, logger: Any, sql: str):
    logger.info(f"SQL> {sql}")
    return spark.sql(sql)


def _parse_csv(v: Optional[str]) -> List[str]:
    if not v:
        return []
    return [x.strip() for x in v.split(",") if x.strip()]


def _in_pred(col: str, vals: List[str]) -> Optional[str]:
    if not vals:
        return None
    if len(vals) == 1:
        return f"{col} = {_sql_literal(vals[0])}"
    return f"{col} IN (" + ", ".join(_sql_literal(x) for x in vals) + ")"


def _describe_columns(spark: SparkSession, logger: Any, name: str) -> List[Tuple[str, str]]:
    rows = _exec_sql(spark, logger, f"DESCRIBE {name}").collect()
    cols: List[Tuple[str, str]] = []
    for r in rows:
        c = (r[0] or "").strip()
        t = (r[1] or "").strip()
        if not c or c.startswith("#"):
            continue
        if c.lower() in ("partitioning", "# partitioning"):
            break
        cols.append((c.lower(), t))
    return cols


def _table_exists(spark: SparkSession, name: str) -> bool:
    return spark.catalog.tableExists(name)


def _resolve_biz_dt(
    spark: SparkSession,
    logger: Any,
    view_name: str,
    src_systems: List[str],
    site_ids: List[str],
    provided: Optional[str],
) -> Optional[str]:
    """Resolve effective biz_dt for this run.

    If provided is non-empty, use it as-is. Otherwise, read the latest biz_dt
    from the central date dimension table filtered by src_system/site_id.

    Note: We intentionally do NOT derive from the large source view to avoid
    scanning heavy datasets just to find MAX(biz_dt).
    """
    if provided:
        return provided
    preds: List[str] = ["1=1"]
    p1 = _in_pred("src_system", src_systems)
    if p1:
        preds.append(p1)
    p2 = _in_pred("site_id", site_ids)
    if p2:
        preds.append(p2)
    where = " AND ".join(preds)
    logger.info(
        "Resolving biz_dt from date dimension",
        extra={"date_dim_table": DATE_DIM_TABLE, "where": where},
    )
    row = _exec_sql(
        spark,
        logger,
        f"SELECT CAST(MAX(biz_dt) AS STRING) AS biz_dt FROM {DATE_DIM_TABLE} WHERE {where}",
    ).collect()[0]
    return row["biz_dt"]


def _choose_partitions(source_cols: List[Tuple[str, str]]) -> List[str]:
    present = {c for c, _ in source_cols}
    return [c for c in ("site_id", "biz_dt") if c in present]


def _add_missing_columns(spark: SparkSession, logger: Any, table_name: str, cols: List[Tuple[str, str]]):
    if not cols:
        return
    defs = ", ".join(f"{_qid(c)} {t}" for c, t in cols)
    _exec_sql(spark, logger, f"ALTER TABLE {table_name} ADD COLUMNS ({defs})")


def _set_dyn_part(spark: SparkSession, logger: Any):
    _exec_sql(spark, logger, "SET hive.exec.dynamic.partition=true")
    _exec_sql(spark, logger, "SET hive.exec.dynamic.partition.mode=nonstrict")


def _get_spark_user(spark: SparkSession) -> str:
    """Return the submitting user as seen by Spark (YARN/CDP propagates OS user)."""
    return spark.sparkContext.sparkUser()


 


def _build_where(srcs: List[str], sites: List[str], biz_dt: str, alias: Optional[str] = None) -> str:
    """Build a WHERE predicate for src_system/site_id/biz_dt with optional alias prefix."""
    prefix = (alias + ".") if alias else ""
    preds: List[str] = ["1=1"]
    p1 = _in_pred(f"{prefix}src_system", srcs)
    if p1:
        preds.append(p1)
    p2 = _in_pred(f"{prefix}site_id", sites)
    if p2:
        preds.append(p2)
    preds.append(f"{prefix}biz_dt = {_sql_literal(biz_dt)}")
    return " AND ".join(preds)


def _count_rows(spark: SparkSession, logger: Any, from_expr: str, where: Optional[str] = None) -> int:
    """Count rows from a table/view or aliased FROM expression with optional WHERE."""
    sql = f"SELECT COUNT(*) AS cnt FROM {from_expr}"
    if where:
        sql += f" WHERE {where}"
    try:
        row = _exec_sql(spark, logger, sql).collect()[0]
        # row may be a Row with key 'cnt' or index 0
        return int(row["cnt"]) if isinstance(row.asDict(), dict) and "cnt" in row.asDict() else int(row[0])
    except Exception:
        return 0


def _load_existing(
    spark: SparkSession,
    args: argparse.Namespace,
    logger: Any,
    source_cols: List[Tuple[str, str]],
    resolved_biz_dt: str,
) -> None:
    target_cols = _describe_columns(spark, logger, args.target_table)
    src_map = {c: t for c, t in source_cols}
    tgt_map = {c: t for c, t in target_cols}
    add_cols = [(c, src_map[c]) for c in src_map.keys() if c not in tgt_map]
    if add_cols:
        _add_missing_columns(spark, logger, args.target_table, add_cols)
        logger.info("Added columns", extra={"columns": [c for c, _ in add_cols]})
        target_cols = _describe_columns(spark, logger, args.target_table)
        tgt_map = {c: t for c, t in target_cols}

    parts = [p for p in ("site_id", "biz_dt") if p in {c for c, _ in target_cols}]
    non_parts = [c for c, _ in target_cols if c not in parts]

    preds: List[str] = ["1=1"]
    srcs = _parse_csv(args.src_system)
    sites = _parse_csv(args.site_id)
    p1 = _in_pred("v.src_system", srcs)
    if p1:
        preds.append(p1)
    p2 = _in_pred("v.site_id", sites)
    if p2:
        preds.append(p2)
    preds.append(f"v.biz_dt = {_sql_literal(resolved_biz_dt)}")
    where = " AND ".join(preds)

    def projection() -> str:
        exprs: List[str] = []
        for col, _ in target_cols:
            if col in src_map:
                exprs.append(f"v.{_qid(col)} AS {_qid(col)}")
            else:
                exprs.append(f"CAST(NULL AS {tgt_map[col]}) AS {_qid(col)}")
        return ", ".join(exprs)

    _set_dyn_part(spark, logger)
    if args.load_method == "append":
        sql = f"INSERT INTO {args.target_table} SELECT {projection()} FROM {args.view_name} v WHERE {where}"
        _exec_sql(spark, logger, sql)
        logger.info("Append completed")
    else:
        if "biz_dt" in parts:
            static_clause = f"biz_dt={_sql_literal(resolved_biz_dt)}"
            exprs: List[str] = []
            for col in non_parts:
                if col in src_map:
                    exprs.append(f"v.{_qid(col)} AS {_qid(col)}")
                else:
                    exprs.append(f"CAST(NULL AS {tgt_map[col]}) AS {_qid(col)}")
            for p in [x for x in parts if x != "biz_dt"]:
                exprs.append(f"v.{_qid(p)} AS {_qid(p)}")
            select_list = ", ".join(exprs)
            sql = (
                f"INSERT OVERWRITE TABLE {args.target_table} PARTITION ({static_clause}) "
                f"SELECT {select_list} FROM {args.view_name} v WHERE {where}"
            )
            _exec_sql(spark, logger, sql)
            logger.info("Overwrite completed (partition)")
        else:
            sql = (
                f"INSERT OVERWRITE TABLE {args.target_table} SELECT {projection()} FROM {args.view_name} v WHERE {where}"
            )
            _exec_sql(spark, logger, sql)
            logger.info("Overwrite completed (full)")


def run(argv: List[str]) -> int:
    args = parse_args(argv)

    # Build Spark first to derive submitting user from Spark
    conf = parse_spark_conf(args.spark_conf)
    if args.spark_executor_instances is not None:
        conf["spark.executor.instances"] = str(args.spark_executor_instances)
    if args.spark_executor_memory:
        conf["spark.executor.memory"] = args.spark_executor_memory
    if args.spark_driver_memory:
        conf["spark.driver.memory"] = args.spark_driver_memory
    if args.spark_executor_cores is not None:
        conf["spark.executor.cores"] = str(args.spark_executor_cores)

    spark = build_spark_session(args.job_name, conf)

    # Resolve submitting user from Spark and initialize logging
    submitting_user = _get_spark_user(spark)
    logger = logging_utils.setup_logging(
        level=args.log_level,
        job_name=args.job_name,
        user_name=submitting_user,
        target_table=args.target_table,
        log_file=args.log_file,
    )
    logger.info(f"Submitting user (Spark): {submitting_user}")
    logger.info(
        "Job start and parameters",
        extra={
            "job_name": args.job_name,
            "view_name": args.view_name,
            "target_table": args.target_table,
            "load_method": args.load_method,
            "src_system": args.src_system,
            "site_id": args.site_id,
            "biz_dt_arg": args.biz_dt,
            "spark_conf": conf,
        },
    )
    # biz_dt validation handled by launcher while parsing config; no validation here

    start_ts = datetime.utcnow()
    num_selected: int = 0
    num_loaded: int = 0
    success = False
    used_biz_dt: Optional[str] = None

    try:
        src_cols = _describe_columns(spark, logger, args.view_name)
        partitions = _choose_partitions(src_cols)
        logger.info(
            "Source schema discovered",
            extra={"source_columns": len(src_cols), "partitions_detected": partitions},
        )
        srcs = _parse_csv(args.src_system)
        sites = _parse_csv(args.site_id)
        if not srcs or not sites:
            raise ValueError("--src-system and --site-id must be non-empty")
        biz_dt = _resolve_biz_dt(spark, logger, args.view_name, srcs, sites, args.biz_dt)
        if not biz_dt:
            raise ValueError("Unable to resolve biz_dt from view")
        used_biz_dt = biz_dt
        logger.info("Resolved business date", extra={"biz_dt": used_biz_dt})

        # Build predicates and count rows for audit (modular)
        where_view = _build_where(srcs, sites, biz_dt, alias="v")
        logger.info(
            "Built filter predicates",
            extra={"where": where_view, "src_system": srcs, "site_id": sites},
        )
        num_selected = _count_rows(spark, logger, f"{args.view_name} v", where_view)
        logger.info("Counted source rows to process", extra={"num_selected": num_selected})

        table_exists = _table_exists(spark, args.target_table)
        logger.info(
            "Checked target table existence",
            extra={"target_table": args.target_table, "exists": table_exists, "partitions": partitions},
        )
        if not table_exists:
            where = where_view
            part_clause = f"PARTITIONED BY ({', '.join(partitions)})" if partitions else ""
            logger.info(
                "Creating target via CTAS (managed)",
                extra={"target_table": args.target_table, "partitions": partitions, "where": where},
            )
            sql = (
                f"CREATE TABLE IF NOT EXISTS {args.target_table} USING PARQUET {part_clause} AS "
                f"SELECT v.* FROM {args.view_name} v WHERE {where}"
            )
            _exec_sql(spark, logger, sql)
            logger.info("Created target table via CTAS (managed; LOCATION inferred by metastore)")
        else:
            logger.info("Loading into existing target table", extra={"target_table": args.target_table})
            _load_existing(spark, args, logger, src_cols, biz_dt)

        # Compute loaded rows in target for the same filter
        where_target = _build_where(srcs, sites, biz_dt, alias=None)
        num_loaded = _count_rows(spark, logger, args.target_table, where_target)
        logger.info(
            "Ingestion completed",
            extra={"num_selected": num_selected, "num_loaded": num_loaded, "biz_dt": used_biz_dt},
        )
        success = True
        return 0
    except Exception:
        logger.exception("Ingestion failed")
        return 1
    finally:
        # Best-effort audit capture
        try:
            configs: Dict[str, Any] = {
                "view_name": args.view_name,
                "target_table": args.target_table,
                "load_method": args.load_method,
                "src_system": args.src_system,
                "site_id": args.site_id,
                "biz_dt": used_biz_dt,
                "spark_conf": conf,
                "success": success,
            }
            audit_capture.capture_audit(
                spark,
                audit_table=AUDIT_TABLE,
                job_name=args.job_name,
                view_name=args.view_name,
                target_table=args.target_table,
                start_time=start_ts,
                end_time=datetime.utcnow(),
                num_read=num_selected,
                num_loaded=(num_loaded if success else 0),
                configs=configs,
            )
        except Exception:
            # Do not fail job termination on audit errors
            pass

        # Unified logging: HDFS copy is performed by the launcher after run completion
        finally:
            spark.stop()


def main() -> None:
    sys.exit(run(sys.argv[1:]))
